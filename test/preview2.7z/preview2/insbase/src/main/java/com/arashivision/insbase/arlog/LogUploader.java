package com.arashivision.insbase.arlog;


import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;


import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class LogUploader {
    private static final String TAG = "LogUploader";
    private static final int ERR_COLLECT = -1;
    private static final int ERR_UPLOAD = -2;

    public static class LogTask {
        WeakReference<Context> context;
        String url;
        int maxSize;
        HashMap<String, String> fields = new HashMap<>();
        Handler handler;
        Listener listener;

        public LogTask(Context context, String url, int maxSize) {
            this.context = new WeakReference<Context>(context);
            this.url = url;
            this.maxSize = maxSize;
        }

        public void setField(String key, String value) {
            fields.put(key, value);
        }

        public interface Listener {
            void onComplete(LogTask logTask, int err);
        }

        public void setListener(Handler handler, Listener listener) {
            this.handler = handler;
            this.listener = listener;
        }
    }

    private static void notifyComplete(final LogTask logTask, final int err) {
        if(logTask.listener == null) {
            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Context context = logTask.context.get();
                    if(context == null) {
                        Log.w(TAG, "context destroyed, no log result toast");
                    }
                    if(err == 0) {
                        Toast.makeText(context, "upload log success", Toast.LENGTH_LONG).show();
                    }
                    else {
                        if(err == ERR_COLLECT) {
                            Toast.makeText(context, "failed collect log", Toast.LENGTH_LONG).show();
                        }
                        else {
                            Toast.makeText(context, "failed upload log", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });
        }
        else {
            logTask.handler.post(new Runnable() {
                @Override
                public void run() {
                    logTask.listener.onComplete(logTask, err);
                }
            });
        }
    }

    private static void deleteFile(String file) {
        new File(file).delete();
    }

    public static void postLog(final LogTask logTask) {
        Context context = logTask.context.get();
        if(context == null) {
            Log.e(TAG, "context invalid");
            return;
        }
        Log.i(TAG, "post log");
        final File logDir = new File(context.getCacheDir(), "log");
        logDir.mkdir();

        new Thread() {
            @Override
            public void run() {
                String filename = Build.MANUFACTURER + "-" + Build.MODEL + "-" +
                        new SimpleDateFormat("MM_dd_HH_mm_ss_SSS").format(new Date()) + ".log";
                String logFile = new File(logDir, filename).getAbsolutePath();
                try {
                    Log.collectLog(logFile, logTask.maxSize);
                } catch(IOException e) {
                    Log.e(TAG, "failed collect log: " + e);
                    notifyComplete(logTask, ERR_COLLECT);
                    return;
                }
                MultipartUtility multipartUtility = new MultipartUtility(logTask.url);
                for(Map.Entry<String, String> entry : logTask.fields.entrySet()) {
                    multipartUtility.addFormField(entry.getKey(), entry.getKey());
                }
                try {
                    multipartUtility.addFilePart("file", logFile).commit();
                } catch(IOException e) {
                    Log.e(TAG, "failed post log file: " + e + ". (" + logFile + ")");
                    notifyComplete(logTask, ERR_UPLOAD);
                    return;
                }

                notifyComplete(logTask, 0);
                deleteFile(logFile);
            }
        }.start();
    }
}
