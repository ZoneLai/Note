package com.arashivision.insbase.graphic;


import android.view.Surface;

import com.arashivision.insbase.NativeLibsLoader;

public class SurfaceUtils {
    static {
        NativeLibsLoader.load();
    }

    public static int getSurfaceWidth(Surface surface) {
        return nativeGetSurfaceWidth(surface);
    }

    public static int getSurfaceHeight(Surface surface) {
        return nativeGetSurfaceHeight(surface);
    }

    public static int setSurfaceBufferSize(Surface surface, int width, int height) {
        return nativeSetSurfaceBufferSize(surface, width, height);
    }


    private native static int nativeGetSurfaceWidth(Surface surface);

    private native static int nativeGetSurfaceHeight(Surface surface);

    private native static int nativeSetSurfaceBufferSize(Surface surface, int width, int height);


}
