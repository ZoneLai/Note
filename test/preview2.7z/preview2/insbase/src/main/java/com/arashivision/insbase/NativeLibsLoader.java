package com.arashivision.insbase;
import android.util.Log;

public class NativeLibsLoader {
    private static final String TAG = "NativeLibsLoader";
    private static final Object mSyncObject = new Object();
    private static boolean mLoaded;

    public static void load() {
        synchronized(mSyncObject) {
            if(mLoaded)
                return;
            Log.i(TAG, "load insbase native libs");
            System.loadLibrary("c++_shared");
            System.loadLibrary("insbase");
            mLoaded = true;
            Log.i(TAG, "insbase native libs loaded");
        }
    }
}
