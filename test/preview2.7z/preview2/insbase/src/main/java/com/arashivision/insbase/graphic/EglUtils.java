package com.arashivision.insbase.graphic;


public class EglUtils {

    public static long getCurrentEglContextNativeHandle() {
        return nativeGetCurrentEglContextNativeHandle();
    }

    private native static long nativeGetCurrentEglContextNativeHandle();
}
