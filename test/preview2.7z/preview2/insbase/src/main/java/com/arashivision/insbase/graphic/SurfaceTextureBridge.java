package com.arashivision.insbase.graphic;

import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Surface;

import com.arashivision.insbase.arlog.Log;

import java.lang.ref.WeakReference;

/**
 * Created by julee on 16-1-15.
 * The whole class is using in JNI.
 */
// call by jni code
class SurfaceTextureBridge {
    private static final String TAG = "SurfaceTextureBridgeJ";
    private long mNativeObject;
    private boolean mReleased = false;
    private boolean mCreated = false;
    private int mTextureID;
    private int mWidth;
    private int mHeight;
    private Surface mSurface;
    private SurfaceTexture mSurfaceTexture;
    private Thread mThread;
    private EventHandler mEventHandler;

    // call in jni
    private SurfaceTextureBridge() {
        Log.i(TAG, "SurfaceTextureBridge constructed");
    }

    private void initLooper() {
        final Boolean[] reply = new Boolean[1];
        reply[0] = false;
        mThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Thread.currentThread().setName("SurfaceTextureBridge");
                Looper.prepare();
                mEventHandler = new EventHandler(SurfaceTextureBridge.this, Looper.myLooper());
                synchronized(reply) {
                    reply[0] = true;
                    reply.notifyAll();
                }
                Looper.loop();
            }
        });
        mThread.start();
        synchronized(reply) {
            while(!reply[0])
                try {
                    reply.wait();
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
        }
    }

    // call in jni
    private Surface createSurface(int texture, int width, int height, long nativeObject) {
        Log.i(TAG, "createSurface: " + texture);
        if(mCreated)
            throw new IllegalStateException("SurfaceTextureBridge already create one surface");
        mCreated = true;
        mNativeObject = nativeObject;
        initLooper();
        Object[] data = new Object[1];
        mTextureID = texture;
        mWidth = width;
        mHeight = height;
        data[0] = false;
        // we need create SurfaceTexture in one Looper-thread, and frame available callback
        // with calls in it(post by SurfaceTexture)
        mEventHandler.sendMessage(mEventHandler.obtainMessage(MSG_SET_SURFACETEXTURE, 0, 0,
                data));
        synchronized(data) {
            while(!(Boolean)data[0]) {
                try {
                    data.wait();
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        mSurface = new Surface(mSurfaceTexture);
        return mSurface;
    }

    // call in jni, in OpenGL rendering thread
    private void updateTexImage() {
        if(!mCreated)
            return;
        mSurfaceTexture.updateTexImage();
    }

    // call in jni
    private float[] getTransformMatrix() {
        float[] matrix = new float[16];
        mSurfaceTexture.getTransformMatrix(matrix);
        return matrix;
    }

    // call in jni
    private void release() {
        Log.i(TAG, "release");
        if(mReleased)
            return;
        mReleased = true;
        if(!mCreated)
            return;
        mEventHandler.sendMessage(mEventHandler.obtainMessage(MSG_QUIT));
        try {
            mThread.join();
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
        mSurface.release();
        mSurfaceTexture.release();
        mSurface = null;
        mSurfaceTexture = null;
        Log.i(TAG, "SurfaceTextureBridge released");
    }

    @Override
    protected void finalize() throws Throwable {
        if(!mReleased) {
            Log.e(TAG, "SurfaceTextureBridge finalize: SHOULD release it manually");
            release();
        }
        super.finalize();
    }

    private native void nativeNotifyFrameAvailable(long nativeObject, boolean aborted);

    public void onFrameAvailable(SurfaceTexture surfaceTexture, boolean aborted) {
        if(mReleased) {
            Log.i(TAG, "onFrameAvailable: SurfaceTextureBridge released");
            return;
        }
        nativeNotifyFrameAvailable(mNativeObject, aborted);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////
    private static final int MSG_SET_SURFACETEXTURE = 1;
    private static final int MSG_QUIT = 2;

    private static class EventHandler extends Handler {
        private WeakReference<SurfaceTextureBridge> mSurfaceTextureBridgeWeakRef;

        public EventHandler(SurfaceTextureBridge creator, Looper looper) {
            super(looper);
            mSurfaceTextureBridgeWeakRef = new WeakReference<SurfaceTextureBridge>(creator);
        }

        @Override
        public void handleMessage(Message msg) {
            SurfaceTextureBridge creator = mSurfaceTextureBridgeWeakRef.get();
            if(creator == null && msg.what != MSG_QUIT) {
                Log.w(TAG, "SurfaceTextureBridge.EventHandler handleMessage: " + msg.what +
                        ", but creator not exists now");
                return;
            }

            int what = msg.what;
            Log.d(TAG, "received notification " + what);
            switch(what) {
                case MSG_SET_SURFACETEXTURE: {
                    Log.i(TAG, "setup surface texture");
                    Object[] data = (Object[])msg.obj;
                    creator.mSurfaceTexture = new SurfaceTexture(creator.mTextureID);
                    creator.mSurfaceTexture.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener() {
                        @Override
                        public void onFrameAvailable(SurfaceTexture surfaceTexture) {
                            SurfaceTextureBridge c = mSurfaceTextureBridgeWeakRef.get();
                            if(c == null) return;
                            c.onFrameAvailable(surfaceTexture, false);
                        }
                    });
                    if(creator.mWidth > 0 && creator.mHeight > 0) {
                        Log.i(TAG, "set surface texture size: " + creator.mWidth + "x" + creator.mHeight);
                        creator.mSurfaceTexture.setDefaultBufferSize(creator.mWidth, creator.mHeight);
                    }
                    synchronized(data) {
                        data[0] = true;
                        data.notifyAll();
                    }
                    break;
                }
                case MSG_QUIT: {
                    if(creator != null)
                        creator.onFrameAvailable(creator.mSurfaceTexture, true);
                    Looper.myLooper().quit();
                    break;
                }
                default:
                    Log.e(TAG, "unknown message for event handler: " + what);

            }
        }
    }
}
