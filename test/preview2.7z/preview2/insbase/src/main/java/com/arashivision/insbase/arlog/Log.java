package com.arashivision.insbase.arlog;


import android.os.Build;

import com.arashivision.insbase.NativeLibsLoader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class Log {
    private static final int LEVEL_VERBOSE = android.util.Log.VERBOSE;
    private static final int LEVEL_DEBUG = android.util.Log.DEBUG;
    private static final int LEVEL_INFO = android.util.Log.INFO;
    private static final int LEVEL_WARN = android.util.Log.WARN;
    private static final int LEVEL_ERROR = android.util.Log.ERROR;
    private static String sLogFile;

    static {
        NativeLibsLoader.load();
        configure(true, false, null, false);
    }

    public static void configure(boolean toLogcat, boolean toFile, String filepath, boolean redirectStd) {
        if(toFile) {
            sLogFile = filepath;
        }
        nativeConfigure(toLogcat, toFile, filepath, redirectStd);
    }

    public static int v(String tag, String msg) {
        return nativeWriteLog(LEVEL_VERBOSE, tag, msg);
    }

    public static int d(String tag, String msg) {
        return nativeWriteLog(LEVEL_DEBUG, tag, msg);
    }

    public static int i(String tag, String msg) {
        return nativeWriteLog(LEVEL_INFO, tag, msg);
    }

    public static int w(String tag, String msg) {
        return nativeWriteLog(LEVEL_WARN, tag, msg);
    }

    public static int e(String tag, String msg) {
        return nativeWriteLog(LEVEL_ERROR, tag, msg);
    }


    private native static void nativeConfigure(boolean toLogcat, boolean toFile, String filepath,
                                               boolean redirectStd);
    private native static int nativeWriteLog(int level, String tag, String msg);

    private static int collectLogcat(FileOutputStream fos, int maxSize) {
        int totalCollected = 0;
        ArrayList<String> commandLine = new ArrayList<>();
        commandLine.add( "logcat");
        commandLine.add( "-d");
        commandLine.add( "-v");
        commandLine.add( "threadtime");
        Process process = null;
        BufferedReader reader = null;

        try {
            try {
                ProcessBuilder builder = new ProcessBuilder(commandLine).redirectErrorStream(true);
                process = builder.start();
            } catch(IOException e) {
                String message = "failed run logcat: " + e;
                byte[] bytes = message.getBytes();
                fos.write(bytes);
                totalCollected += bytes.length;
                Log.e("Insta360", "[Log.java]" + message);
            }

            reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder stringBuffer = new StringBuilder();
            String line = null;
            while((line = reader.readLine()) != null) {
                stringBuffer.append(line);
                stringBuffer.append('\n');
            }

            Log.i("Insta360", "[Log.java] available log size: " + stringBuffer.length());
            int readSize = Math.min(stringBuffer.length(), maxSize);
            if(readSize <= 0) {
                return totalCollected;
            }
            String collectContent = stringBuffer.substring(stringBuffer.length() - readSize);
            byte[] bytes = collectContent.getBytes();
            fos.write(bytes, 0, bytes.length);
            totalCollected += bytes.length;

            fos.write("\n".getBytes());
            fos.write("################################################################################################################\n".getBytes());
            fos.write("\n\n\n\n".getBytes());

            do {
                try {
                    process.waitFor();
                    process = null;
                    break;
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
            } while(true);
        } catch(IOException e) {
            Log.e("Insta360", "[Log.java] write log file failed: " + e);
            e.printStackTrace();
        } finally {
            if(reader != null) {
                try {
                    reader.close();
                    reader = null;
                } catch(IOException e) {
                    e.printStackTrace();
                }
            }
            if(process != null) {
                // we can't waitFor process here, as we doesn't read it's stdout/stderr, process may
                // run in PIPE_WAIT state, waitFor may deadlock with the process.
                Log.w("Insta360", "[Log.java] destroy process");
                process.destroy();
                process = null;
            }
        }

        return totalCollected;
    }

    public static void collectLog(String filePath, int wholeFileMaxSize, int logcatPartSize) throws IOException {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(filePath);
        } catch(IOException e) {
            throw new IOException("failed create output file: " + filePath, e);
        }

        fos.write(String.format(Locale.getDefault(), "model:%s, product:%s, device:%s, manufacturer:%s, " +
                        "android version:%d, soc model:%s\n\n",
                Build.MODEL, Build.PRODUCT, Build.DEVICE, Build.MANUFACTURER, Build.VERSION.SDK_INT,
                getCpuName()).getBytes());

        try {
            long logFileSize = 0;
            if(sLogFile != null)
                logFileSize = new File(sLogFile).length();

            //fileMaxSize - logFileSize;
            int logcatSize = collectLogcat(fos, (int)Math.max(wholeFileMaxSize - logFileSize, logcatPartSize));
            wholeFileMaxSize -= logcatSize;
            if(wholeFileMaxSize <= 0)
                return;

            if(logFileSize > 0) {
                FileInputStream fis = null;
                try {
                    fis = new FileInputStream(sLogFile);
                    long readSize = Math.min(wholeFileMaxSize, logFileSize);
                    fis.skip(logFileSize - readSize);

                    byte[] buf = new byte[16384];
                    for(; ; ) {
                        int readBytes = fis.read(buf);
                        if(readBytes == -1)
                            break;
                        fos.write(buf, 0, readBytes);
                    }
                } catch(IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if(fis != null)
                            fis.close();
                    } catch(IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } finally {
            try {
                fos.close();
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void collectLog(String filePath, int wholeFileMaxSize) throws IOException{
        collectLog(filePath, wholeFileMaxSize, 40960);
    }

    public static void postLog(String filePath, String url) throws IOException {
        new MultipartUtility(url).addFilePart("file", filePath).commit();
    }

    private static String getCpuName() {
        FileInputStream fis = null;
        BufferedReader reader = null;
        try {
            fis = new FileInputStream("/proc/cpuinfo");
            reader = new BufferedReader(new InputStreamReader(fis));
            String line;
            String hardware = null;
            String modelName = null;
            while((line = reader.readLine()) != null) {
                if(line.startsWith("Hardware") || line.startsWith("model name")) {
                    int offset = line.indexOf(":");
                    if(offset != -1) {
                        String name = line.substring(offset + 1);
                        name = name.trim();
                        if(!name.isEmpty()) {
                            if(line.startsWith("Hardware"))
                                hardware = name;
                            else
                                modelName = name;
                        }

                    }
                }
            }
            if(hardware != null)
                return hardware;
            else if(modelName != null)
                return modelName;
        } catch(IOException e) {
            Log.e("Insta360", "Log: failed open /proc/cpuinfo: " + e);
        } finally {
            if(reader != null)
                try {
                    reader.close();
                } catch(IOException e) {
                    e.printStackTrace();
                }
            if(fis != null)
                try {
                    fis.close();
                } catch(IOException e) {
                    e.printStackTrace();
                }
        }
        return "";
    }
}
