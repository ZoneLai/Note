package com.arashivision.insbase;


import android.content.Context;

import com.arashivision.insbase.arlog.Log;
import com.arashivision.insbase.sys.SysInfo;

public class InsBase {
    private static boolean sInited;

    public static synchronized void init(Context appContext) {
        if(appContext == null)
            throw new NullPointerException();
        if(sInited)
            return;
        SysInfo.init(appContext.getApplicationContext());
        NativeLibsLoader.load();
        sInited = true;
    }

    public static void initLog(boolean toLogcat, boolean toFile, String logFilePath, boolean redirectStd) {
        Log.configure(toLogcat, toFile, logFilePath, redirectStd);
    }
}
