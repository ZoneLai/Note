package com.arashivision.insbase.sys;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.arashivision.insbase.NativeLibsLoader;

// call by jni code
public class SysInfo {
    private static final String TAG = "SysInfo";
    @SuppressLint("StaticFieldLeak")
    private static Context mAppContext;
    private static final Object mSyncObject = new Object();

    static {
        NativeLibsLoader.load();
    }

    public static void init(Context context) {
        if(context == null)
            throw new NullPointerException("context should not be null");
        context = context.getApplicationContext();
        synchronized(mSyncObject) {
            if(mAppContext != null)
                return;
            mAppContext = context;
            nativeInit();
        }
    }

    // call in jni
    private static String getInfo(String name) {
        if(mAppContext == null) {
            Log.e(TAG, "SysInfo not init yet");
            return "";
        }
        if(name.equals("DataDirectory")) {
            return mAppContext.getFilesDir().getAbsolutePath();
        }
        if(name.equals("ExternalStorage")) {
            return Environment.getExternalStorageDirectory().getAbsolutePath();
        }
        else {
            Log.e(TAG, "unknown info item: " + name);
            return "";
        }
    }

    private static native void nativeInit();

}
