package com.arashivision.insbase.types;


import java.util.HashMap;

// call by jni code
class HashMapBridge {

    public static Object stringStringHashMapNew() {
        return new HashMap<>();
    }

    public static String[] stringStringHashMapKeys(Object map) {
        return (String[])((HashMap<String, String>)map).keySet().toArray(new String[]{});
    }

    public static String stringStringHashMapGet(Object map, String key) {
        return ((HashMap<String,String>)map).get(key);
    }

    public static String stringStringHashMapPut(Object map, String key, String value) {
        return ((HashMap<String,String>)map).put(key, value);
    }


}
