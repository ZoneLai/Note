package com.arashivision.insbase.arlog;


import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.UUID;

public class MultipartUtility {
    private static final String CTRLF = "\r\n";
    private static final String TWO_HYPHENS = "--";
    private final String mRequestUrl;
    private final String mBoundary;
    private ArrayList<Part> mParts = new ArrayList<Part>();

    private enum PartType { STRING, FILE }

    private interface Part {
        PartType getType();
        long getSize();
    }

    private class FilePart implements Part {
        String fieldName;
        long fieldSize;
        byte[] head;
        byte[] end;
        File file;
        long fileLength;

        public FilePart(String fieldName, String filepath) {
            this.fieldName = fieldName;
            this.file = new File(filepath);
            if(!this.file.isFile())
                throw new RuntimeException("file: " + filepath + " is not a file");
            fileLength = file.length();
            String fileName = file.getName();
            StringBuilder builder = new StringBuilder();
            builder.append(TWO_HYPHENS).append(mBoundary).append(CTRLF);
            builder.append("Content-Disposition: form-data; name=\"").append(fieldName).
                    append("\";filename=\"").append(fileName).append("\"").append(CTRLF);
            builder.append(CTRLF);
            try {
                head = builder.toString().getBytes("UTF-8");
                end = CTRLF.getBytes("UTF-8");
            } catch(UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }
            this.fieldSize = head.length + end.length + fileLength;
        }

        public PartType getType() {
            return PartType.FILE;
        }

        @Override
        public long getSize() {
            return fieldSize;
        }
    }

    private class StringPart implements Part {
        String name;
        String value;
        byte[] content;

        StringPart(String fieldName, String value) {
            this.name = fieldName;
            this.value = value;
            StringBuilder builder = new StringBuilder();
            builder.append(TWO_HYPHENS).append(mBoundary).append(CTRLF);
            builder.append("Content-Disposition: form-data; name=\"").append(fieldName).append("\"").append(CTRLF);
            builder.append("Content-Type: text/plain; charset=UTF-8" + CTRLF);
            builder.append(CTRLF);
            builder.append(value);
            builder.append(CTRLF);
            try {
                content = builder.toString().getBytes("UTF-8");
            } catch(UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }
        }

        public PartType getType() {
            return PartType.STRING;
        }

        @Override
        public long getSize() {
            return content.length;
        }
    }


    /**
     * This constructor initializes a new HTTP POST mOutputStream with content type
     * is set to multipart/form-data
     *
     * @param requestUrl
     */
    public MultipartUtility(String requestUrl) {
        mBoundary = UUID.randomUUID().toString();
        mRequestUrl = requestUrl;
    }

    /**
     * Adds a form field to the mOutputStream
     *
     * @param name  field fieldName
     * @param value field value
     */
    public MultipartUtility addFormField(String name, String value) {
        mParts.add(new StringPart(name, value));
        return this;
    }

    /**
     * Adds a upload file section to the mOutputStream
     *
     * @param fieldName  fieldName attribute in <input type="file" fieldName="..." />
     * @param uploadFilePath a File to be uploaded
     */
    public MultipartUtility addFilePart(String fieldName, String uploadFilePath) {
        mParts.add(new FilePart(fieldName, uploadFilePath));
        return this;
    }

    /**
     * Completes the mOutputStream and receives response from the server.
     *
     * @return a list of Strings as response in case the server returned
     * status OK, otherwise an exception is thrown.
     * @throws IOException
     */
    public String commit() throws IOException {
        String response ="";

        long totalLength = 0;
        for(Part part : mParts) {
            totalLength += part.getSize();
        }
        byte[] headEndBytes = (TWO_HYPHENS + mBoundary + TWO_HYPHENS + CTRLF).getBytes("UTF-8");
        totalLength += headEndBytes.length;

        // creates a unique boundary based on time stamp
        URL url = new URL(mRequestUrl);
        HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
        httpConnection.setUseCaches(false);
        httpConnection.setDoOutput(true); // indicates POST method
        httpConnection.setDoInput(true);
        httpConnection.setFixedLengthStreamingMode((int)totalLength);

        httpConnection.setRequestMethod("POST");
        httpConnection.setRequestProperty("Connection", "Keep-Alive");
        httpConnection.setRequestProperty("Cache-Control", "no-cache");
        httpConnection.setRequestProperty(
                "Content-Type", "multipart/form-data;boundary=" + mBoundary);

        DataOutputStream outputStream = new DataOutputStream(httpConnection.getOutputStream());
        for(Part part : mParts) {
            if(part.getType() == PartType.STRING) {
                StringPart stringPart = (StringPart)part;
                outputStream.write(stringPart.content);
            }
            else if(part.getType() == PartType.FILE) {
                FilePart filePart = (FilePart)part;
                outputStream.write(filePart.head);

                FileInputStream fis = new FileInputStream(filePart.file);
                long actualSendFileSize = 0;
                byte[] fileBuf = new byte[16384];
                for(;;) {
                    int numReadBytes = fis.read(fileBuf);
                    if(numReadBytes == -1)
                        break;
                    actualSendFileSize += numReadBytes;
                    outputStream.write(fileBuf, 0, numReadBytes);
                }
                if(actualSendFileSize != filePart.fileLength)
                    throw new RuntimeException("upload file's size changed: " + filePart.fileLength
                        + "->" + actualSendFileSize);

                outputStream.write(filePart.end);
            }
        }

        outputStream.write(headEndBytes);
        outputStream.flush();
        outputStream.close();

        // checks server's status code first
        int status = httpConnection.getResponseCode();
        Log.i("MultipartUtility", "response code: " + status);
        if (status < 400) {
            InputStream responseStream = new
                    BufferedInputStream(httpConnection.getInputStream());

            BufferedReader responseStreamReader =
                    new BufferedReader(new InputStreamReader(responseStream));

            String line = "";
            StringBuilder stringBuilder = new StringBuilder();

            while ((line = responseStreamReader.readLine()) != null) {
                stringBuilder.append(line).append("\n");
            }
            responseStreamReader.close();

            response = stringBuilder.toString();
            httpConnection.disconnect();
        } else {
            throw new IOException("Server response: " + status);
        }

        //Log.i("MultipartUtility", "response: " + response);
        return response;
    }
}