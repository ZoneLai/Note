package com.lza.shapeimageview;

import android.content.Context;
import android.util.AttributeSet;

import com.lza.shapeimageview.shader.ShaderHelper;
import com.lza.shapeimageview.shader.SvgShader;

/**
 * @作者： @赖忠安
 * @创建时间： @2017-04-25
 */

public class HeartImageView extends ShaderImageView {

    public HeartImageView(Context context) {
        super(context);
    }

    public HeartImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public HeartImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public ShaderHelper createImageViewHelper() {
        return new SvgShader(R.raw.imgview_heart, SvgShader.BORDER_TYPE_FILL);
    }
}
