package com.arashivision.graphicpath.preview;


/**
 * @author dell
 * @date 2018/7/16
 */

public class Preview {
    private static final String TAG = "graphicpath";
    private long mObjPtr = 0L;

    public Preview() {
        mObjPtr = nativeOnCreate();
    }

    public void addVideoClip(String filePath, long startTimeMs, long endTimeMs,
                             long scaleStartTimeMs, long scaleEndTimeMs, double factor) {
        nativeAddVideoClip(mObjPtr, filePath, startTimeMs, endTimeMs, scaleStartTimeMs, scaleEndTimeMs, factor);
    }

    public void addAudioClip(String filePath, long startTimeMs, long endTimeMs,
                             long scaleStartTimeMs, long scaleEndTimeMs, double factor) {
        nativeAddAudioClip(mObjPtr, filePath, startTimeMs, endTimeMs, scaleStartTimeMs, scaleEndTimeMs, factor);
    }

    public void addAudioMixClip(String filePath, long startTimeMs, long endTimeMs,
                                long scaleStartTimeMs, long scaleEndTimeMs, double factor, double weight) {
        nativeAddAudioMixClip(mObjPtr, filePath, startTimeMs, endTimeMs, scaleStartTimeMs, scaleEndTimeMs, factor, weight);
    }

    public void addEmptyClip(long time) {
        nativeAddEmptyClip(mObjPtr, time);
    }

    public void addImageClip(String image, long time) {
        nativeAddImageClip(mObjPtr, image, time);
    }

    public void onStart() {
        nativeOnStart(mObjPtr);
    }

    public void onDestroy() {
        nativeOnDestroy(mObjPtr);
    }

    public long getSourceObject() {
        return mObjPtr;
    }

    public void setPause() {
        nativeSetPause(mObjPtr);
    }

    public void setPlayRate(int rate) {
        nativeSetPlayRate(mObjPtr, rate);
    }

    public void seekValue(long value) {
        nativeSeekValue(mObjPtr, value);
    }


    private native long nativeOnCreate();

    private native void nativeAddVideoClip(long objPtr, String filePath, long startTimeMs, long endTimeMs,
                                           long scaleStartTimeMs, long scaleEndTimeMs, double factor);

    private native void nativeAddAudioClip(long objPtr, String filePath, long startTimeMs, long endTimeMs,
                                           long scaleStartTimeMs, long scaleEndTimeMs, double factor);

    private native void nativeAddAudioMixClip(long objPtr, String filePath, long startTimeMs, long endTimeMs,
                                              long scaleStartTimeMs, long scaleEndTimeMs, double factor, double weight);

    private native void nativeAddEmptyClip(long objPtr, long timeRange); // Audio

    private native void nativeAddImageClip(long objPtr, String imageFile, long time);

    private native void nativeOnStart(long objPtr);

    private native void nativeOnDestroy(long objPtr);

    private native long nativeGetSourceObject(long objPtr);

    private native void nativeSetPause(long objPtr);

    private native void nativeSetPlayRate(long objPtr, int rate); // 0、默认，1、0.25倍，2、0.5倍，3、2倍，4、4倍

    private native void nativeSeekValue(long objPtr, long value);

}
