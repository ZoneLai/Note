package com.arashivision.graphicpath.render;


/**
 * @author dell
 */
public interface Render {
    long getNativeInstance();

    void onDestroy();
}
