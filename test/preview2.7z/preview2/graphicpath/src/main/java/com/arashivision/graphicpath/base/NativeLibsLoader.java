package com.arashivision.graphicpath.base;


public class NativeLibsLoader {
    private static boolean mLoaded;

    public synchronized static void load() {
        if(mLoaded)
            return;
        System.loadLibrary("c++_shared");
        System.loadLibrary("event");
        System.loadLibrary("arypto");
        System.loadLibrary("asl");
        System.loadLibrary("turbojpeg");
        System.loadLibrary("insbase");
        System.loadLibrary("graphicpath");
    }
}
