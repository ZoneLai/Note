package com.arashivision.graphicpath.render;


import com.arashivision.graphicpath.utils.MediaUtil;

/**
 * @author dell
 * @date 2018/6/20
 */

public class HybridRender implements Render {
    private static final String TAG = "graphicpath";
    private long mNativeInstance = 0L;

    public HybridRender() {
        nativeOnCreate();
    }

    public void initHyBridVideoRender(final String filePath) {
        if (null == filePath) {
            throw new NullPointerException();
        }
        nativeInitHyBridVideoRender(filePath);
    }

    public void initHyBridImageRender(final String imagePath) {
        if (null == imagePath) {
            throw new NullPointerException();
        }
        nativeInitHyBridImageRender(imagePath);
    }

    public void initHybridRender(final String filePath) {
        if (MediaUtil.isVideoFileType(filePath)) {
            nativeInitHyBridVideoRender(filePath);
        } else if (MediaUtil.isImageFileType(filePath)) {
            nativeInitHyBridImageRender(filePath);
        }
    }

    @Override
    public void onDestroy() {
        nativeOnDestroy();
    }

    @Override
    public long getNativeInstance() {
        return mNativeInstance;
    }

    public void onStart() {
        nativeOnStart();
    }

    public void onPuase() {
        nativeOnPause();
    }

    public void setLogoFeature(final String path, final int type) {
        if (null == path) {
            throw new NullPointerException();
        }
        nativeSetLogoFeature(path, type);
    }

    public void setStabilizerFeature(final int type) {
        nativeSetStabilizerFeature(type);
    }

    public void setImageFilterFeature() {
        nativeSetImageFilterFeature();
    }

    public void setSphereViewMode(final int type) {
        nativeSetSphereViewMode(type);
    }

    public void setRenderModelType(final int type) {
        nativeSetRenderModelType(type);
    }

    public void addSticker(String photo, float size, float x, float y) {
        nativeAddSticker(photo, size, x, y);
    }

    public void setSource(long source) {
        nativeSetSource(source);
    }

    private native void nativeOnCreate();   // 创建

    private native void nativeInitHyBridVideoRender(final String filePath); // 初始化视频Render

    private native void nativeInitHyBridImageRender(final String filePath); // 初始化图片Render

    private native void nativeOnStart();    // 播放

    private native void nativeOnPause();    // 暂停

    private native void nativeOnDestroy();  // 销毁

    private native void nativeSetLogoFeature(final String path, final int type);    // 0、extra，1、ON，2，OFF

    private native void nativeSetStabilizerFeature(final int type);     // AUTO = 0, ON = 1，OFF = 2

    private native void nativeSetImageFilterFeature();

    private native void nativeSetSphereViewMode(final int videoType);   // 0、鱼眼，1、普通全景，2、小行星，3、水晶球

    private native void nativeSetRenderModelType(final int renderType); // 设置渲染模式

    private native void nativeAddSticker(final String path, final float size, final float x, final float y);    // 贴纸

    private native void nativeSetSource(long sourcePtr);

}
