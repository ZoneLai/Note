package com.arashivision.graphicpath.ui;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;

import com.arashivision.graphicpath.render.Render;


public class GraphicView extends FrameLayout {
    private static final String TAG = "graphicpath";
    private final int DEFAULT_WIDTH = 1080;
    private final int DEFAUTL_HEIGHT = 1920;

    private long mNativeInstance;
    private SurfaceView mSurfaceView;
    private Render mRender;

    public GraphicView(@NonNull Context context) {
        super(context);
        nativeCreate();
        initView();
    }

    public GraphicView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        nativeCreate();
        initView();
    }

    public GraphicView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        nativeCreate();
        initView();
    }

    public GraphicView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        nativeCreate();
        initView();
    }

    public void initView() {
        mSurfaceView = new SurfaceView(getContext());
        addView(mSurfaceView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        mSurfaceView.getHolder().addCallback(mSurfaceCallback);
        mSurfaceView.setOnTouchListener(mSurfaceViewTouchListener);
    }

    private SurfaceHolder.Callback mSurfaceCallback = new SurfaceHolder.Callback() {

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            nativeSurfaceCreated(holder.getSurface(), DEFAULT_WIDTH, DEFAUTL_HEIGHT);
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            nativeSurfaceChanged(width, height);
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            nativeSurfaceDestroyed();
        }
    };

    // FIXME: to support native 中， 在 render 未 start 情况下，设置 render 给 view
    public void setRender(Render render) {
        mRender = render;
        nativeSetRender(render != null ? render.getNativeInstance() : 0);
    }

    public void onRelease() {
        nativeRemoveRender();
        nativeDestroy();
        mRender = null;
    }

    private OnTouchListener mSurfaceViewTouchListener = new OnTouchListener() {
        private float[] xList = new float[10];
        private float[] yList = new float[10];
        private int[] pointerIDList = new int[10];

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            int pointerCount = Math.min(event.getPointerCount(), pointerIDList.length);
            for (int i = 0; i < pointerCount; ++i) {
                pointerIDList[i] = event.getPointerId(i);
                xList[i] = event.getX(i);
                yList[i] = event.getY(i);
            }
            nativeOnTouch(event.getActionMasked(), event.getActionIndex(), pointerCount,
                    event.getEventTime(), xList, yList, pointerIDList);
            return true;
        }
    };

    private native void nativeCreate();

    private native void nativeDestroy();

    private native void nativeSurfaceCreated(Surface surface, int width, int height);

    private native void nativeSurfaceChanged(int width, int height);

    private native void nativeSurfaceDestroyed();

    private native void nativeSetRender(long render);

    private native void nativeRemoveRender();

    private native void nativeOnTouch(int actionMasked, int actionIndex, int pointerCount, long eventTime, float[] xList, float[] yList, int[] pointerIDList);
}