package com.arashivision.bmgandroid.config;


import android.os.Environment;

import java.io.File;

public class PathConfig {
    // PS：注意程序中所有出现的路径，结尾都不带 "/"

    public static String getMediaFolder() {
        return Environment.getExternalStorageDirectory() + File.separator
                + Environment.DIRECTORY_DCIM + File.separator + "Camera";
    }
}
