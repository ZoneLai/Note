package com.arashivision.bmgandroid;

import android.app.Application;

import com.arashivision.insbase.InsBase;


public class BmgApplication extends Application {

    private static BmgApplication INSTANCE;
    private static String LOG_FILE_PATH = "/sdcard/bmg.log";

    static {
        System.loadLibrary("c++_shared");
        System.loadLibrary("arypto");
        System.loadLibrary("asl");
        System.loadLibrary("turbojpeg");
        System.loadLibrary("insbase");
        System.loadLibrary("graphicpath");
        System.loadLibrary("insbase");
    }

    public static BmgApplication getInstance() {
        return INSTANCE;
    }

    @Override
    public void onCreate() {
        INSTANCE = this;
        super.onCreate();
        InsBase.init(getApplicationContext());
        InsBase.initLog(true, true, LOG_FILE_PATH, true);
    }

}
