package com.arashivision.bmgandroid.activities;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.arashivision.bmgandroid.R;
import com.arashivision.bmgandroid.base.BaseActivity;
import com.arashivision.bmgandroid.bean.FilterInfo;
import com.arashivision.graphicpath.preview.Preview;
import com.arashivision.graphicpath.render.HybridRender;
import com.arashivision.graphicpath.ui.GraphicView;
import com.lza.shapeimageview.RoundedImageView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author dell
 */
public class FilterActivity extends BaseActivity {
    @BindView(R.id.gv_display)
    GraphicView gv_display;

    @BindView(R.id.rv_filter)
    RecyclerView rv_filter;

    @BindView(R.id.cb_filter)
    CheckBox cb_filter;

    ArrayList<FilterInfo> filterInfos = new ArrayList<>();
    FilterAdapter filterAdapter;
    private RoundedImageView roundedImageView = null;

    private Preview mPreview;
    private HybridRender mHybridRender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);
        initFilter();
        initView();
    }

    private void initView() {
        mPreview = new Preview();
        mPreview.addVideoClip("/sdcard/VID_20180115_165332_128.insv", 10000, 40000, 11000, 14000, 1.0);
        mPreview.addAudioClip("/sdcard/VID_20180115_165332_128.insv", 10000, 40000, 11000, 14000, 1.0);
        mPreview.addAudioMixClip("/sdcard/childhood.mp4", 0, 40000, 11000, 14000, 1.0, 5.0);
        mPreview.onStart();
        mHybridRender = new HybridRender();
        mHybridRender.setSource(mPreview.getSourceObject());
        gv_display.setRender(mHybridRender);
    }

    private void initFilter() {
        final int margin = getResources().getDimensionPixelOffset(R.dimen.dp_15);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rv_filter.setLayoutManager(linearLayoutManager);
        rv_filter.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
                super.onDraw(c, parent, state);
            }

            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                outRect.set(0, 0, margin, 0);
            }
        });

        filterInfos.add(new FilterInfo(getString(R.string.filter_name_original), R.drawable.filter_img_01original, "", true));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_budapest), R.drawable.filter_img_06inkwell, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_chaplin), R.drawable.filter_img_03brannan, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_autumn), R.drawable.filter_img_02rise, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_oak), R.drawable.filter_img_10sketch, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_monroe), R.drawable.filter_img_04xproii, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_dejavu), R.drawable.filter_img_03hudson, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_lavie), R.drawable.filter_img_07sierra, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_lucifer), R.drawable.filter_img_09sutro, "", false));
        filterInfos.add(new FilterInfo(getString(R.string.filter_name_memo), R.drawable.filter_img_05walden, "", false));
        filterAdapter = new FilterAdapter();
        rv_filter.setAdapter(filterAdapter);
        filterAdapter.notifyDataSetChanged();
    }

    @OnClick({R.id.cb_filter})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cb_filter:
                rv_filter.setVisibility(cb_filter.isChecked() ? View.VISIBLE : View.GONE);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        gv_display.onRelease();
        mPreview.onDestroy();
        mHybridRender.onDestroy();
        super.onDestroy();
    }

    class FilterAdapter extends RecyclerView.Adapter<FilterAdapter.GalleryViewHolder> {
        @Override
        public FilterAdapter.GalleryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            FilterAdapter.GalleryViewHolder holder = new FilterAdapter.GalleryViewHolder(
                    LayoutInflater.from(FilterActivity.this).inflate(R.layout.item_filter, parent, false));
            return holder;
        }

        @Override
        public void onBindViewHolder(FilterAdapter.GalleryViewHolder holder, int position) {
            FilterInfo filterInfo = filterInfos.get(position);
            holder.riv_filter.setTag(filterInfo);
            holder.riv_filter.setImageResource(filterInfo.resId);
            holder.tv_name.setText(filterInfo.filterName);
            if (filterInfo.isSelected) {
                holder.riv_filter.setBorderColor(R.color.C_FF_67_1B);
                roundedImageView = holder.riv_filter;
            } else {
                holder.riv_filter.setBorderColor(R.color.C_00_00_00_00);
            }
            holder.riv_filter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    roundedImageView.setBorderColor(R.color.C_00_00_00_00);
//                    FilterInfo roundFilterInfo = (FilterInfo) roundedImageView.getTag();
//                    roundFilterInfo.isSelected = false;
//                    FilterInfo filterInfo = (FilterInfo) v.getTag();
//                    filterInfo.isSelected = true;
//                    roundedImageView = (RoundedImageView) v;
//                    roundedImageView.setBorderColor(R.color.C_FF_67_1B);
//                    cv_camera.doUpdateLutFilter(
//                            CameraActivity.this.getAssets(),
//                            filterInfo.filterFileName, filterInfo.filterType);
                    Toast.makeText(FilterActivity.this, "filter show", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return filterInfos.size();
        }

        class GalleryViewHolder extends RecyclerView.ViewHolder {
            View view;
            RoundedImageView riv_filter;
            TextView tv_name;

            public GalleryViewHolder(View view) {
                super(view);
                this.view = view;
                riv_filter = view.findViewById(R.id.riv_filter);
                tv_name = view.findViewById(R.id.tv_name);
            }
        }
    }
}
