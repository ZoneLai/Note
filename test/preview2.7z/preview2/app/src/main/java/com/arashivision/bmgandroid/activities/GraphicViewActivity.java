package com.arashivision.bmgandroid.activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.View;

import com.arashivision.bmgandroid.R;
import com.arashivision.bmgandroid.base.BaseActivity;
import com.arashivision.graphicpath.preview.Preview;
import com.arashivision.graphicpath.render.HybridRender;
import com.arashivision.graphicpath.ui.GraphicView;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author dell
 */
public class GraphicViewActivity extends BaseActivity {

    @BindView(R.id.graphicView)
    GraphicView mGraphicView;

    @BindView(R.id.fab)
    FloatingActionButton mFab;

    private Preview mPreview;
    private HybridRender mHybridRender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphic_view);
        mPreview = new Preview();
        mPreview.addVideoClip("/sdcard/mv1.mp4", 10000, 15000, 11000, 14000, 1.0);
        mPreview.addImageClip("/sdcard/bg.jpg", 2000);
        mPreview.addVideoClip("/sdcard/mv1.mp4", 30000, 40000, 30000, 40000, 1.0);

        mPreview.addAudioClip("/sdcard/mv1.mp4", 10000, 15000, 11000, 14000, 1.0);
        mPreview.addEmptyClip(2000);
        mPreview.addAudioClip("/sdcard/mv1.mp4", 30000, 40000, 30000, 35000, 1.0);

        mPreview.addAudioMixClip("/sdcard/childhood.mp4", 0, 20000, 11000, 14000, 1.0, 5.0);
        mPreview.onStart();

        mHybridRender = new HybridRender();
        mHybridRender.setSource(mPreview.getSourceObject());

        mGraphicView.setRender(mHybridRender);
    }

    @OnClick({R.id.fab})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fab:
                mPreview.seekValue(10000);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        mGraphicView.onRelease();
        mPreview.onDestroy();
        mHybridRender.onDestroy();
        super.onDestroy();
    }
}
