package com.arashivision.bmgandroid.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.arashivision.bmgandroid.R;
import com.arashivision.bmgandroid.base.BaseActivity;

import java.util.ArrayList;

/**
 * @author dell
 */
public class MainActivity extends BaseActivity implements View.OnClickListener {

    private RecyclerView mRecyclerView;
    private ArrayList<MenuBean> mArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView = findViewById(R.id.rv_list);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false));
        mArrayList = new ArrayList<>();
        add("HybridRender", HybridActivity.class);
        add("Preview2", GraphicViewActivity.class);
        add("Filter", FilterActivity.class);
        mRecyclerView.setAdapter(new MenuAdapter());
    }

    private void add(String name, Class<?> clazz) {
        MenuBean bean = new MenuBean();
        bean.name = name;
        bean.clazz = clazz;
        mArrayList.add(bean);
    }

    private class MenuBean {
        String name;
        Class<?> clazz;
    }

    private class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuHolder> {

        @Override
        public MenuHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new MenuHolder(getLayoutInflater().inflate(R.layout.item_select, parent,
                    false));
        }

        @Override
        public void onBindViewHolder(MenuHolder holder, int position) {
            holder.setPosition(position);
        }

        @Override
        public int getItemCount() {
            return mArrayList.size();
        }

        class MenuHolder extends RecyclerView.ViewHolder {
            private TextView tv_select;

            MenuHolder(View itemView) {
                super(itemView);
                tv_select = itemView.findViewById(R.id.tv_select);
                tv_select.setOnClickListener(MainActivity.this);
            }

            public void setPosition(int position) {
                MenuBean bean = mArrayList.get(position);
                tv_select.setText(bean.name);
                tv_select.setTag(position);
            }
        }
    }

    @Override
    public void onClick(View view) {
        int position = (int) view.getTag();
        MenuBean bean = mArrayList.get(position);
        startActivity(new Intent(this, bean.clazz));
    }

}
