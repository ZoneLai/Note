package com.arashivision.bmgandroid.activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.View;
import android.widget.Toast;

import com.arashivision.bmgandroid.R;
import com.arashivision.bmgandroid.base.BaseActivity;
import com.arashivision.graphicpath.render.HybridRender;
import com.arashivision.graphicpath.ui.GraphicView;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author dell
 * @date 2018/7/26
 */

public class HybridActivity extends BaseActivity {

    @BindView(R.id.graphicView)
    GraphicView mGraphicView;

    @BindView(R.id.fab)
    FloatingActionButton mFab;

    private HybridRender mHybridRender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphic_view);
        mHybridRender = new HybridRender();
        mHybridRender.initHybridRender("/sdcard/VID_20180115_165332_128.insv");
        mGraphicView.setRender(mHybridRender);
    }

    @OnClick({R.id.fab})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fab:
                mHybridRender.setSphereViewMode(2);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        mGraphicView.onRelease();
        mHybridRender.onDestroy();
        super.onDestroy();
    }
}
