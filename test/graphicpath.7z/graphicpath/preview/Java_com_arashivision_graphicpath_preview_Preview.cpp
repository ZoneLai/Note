/******************************************************************* 
 *  Copyright(c) 2017-2018 Insta360 Inc.
 *  All rights reserved. 
 *   
 *  @file 	 Java_com_arashivision_graphicpath_preview_Preview.cpp
 *  @brief   Java native interface
 *   
 *  @date    2018-07-16
 *  @author  laizhongan@insta360.com  
 ******************************************************************/ 
#ifndef _Included_com_arashivision_preview_Preview
#define _Included_com_arashivision_preview_Preview
#include "jniutils/JniObject.h"
#include <jniutils/JniUtils.h>
#include "PreviewManager.h"

using namespace Oryol;
using namespace arvrender;

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jlong JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeOnCreate(JNIEnv *env, jobject thiz)
{
	auto previewManager = new PreviewManager();
	previewManager->OnCreate();
	return ((jlong)previewManager);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeAddVideoClip(JNIEnv *env, jobject thiz, jlong objPtr, jstring jFilePath,
	jlong startTimeMs, jlong endTimeMs, jlong scaleStartTimeMs, jlong scaleEndTimeMs, jdouble factor)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	previewManager->AddVideoClip(filePath, startTimeMs, endTimeMs, scaleStartTimeMs, scaleEndTimeMs, factor);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeAddAudioClip(JNIEnv *env, jobject thiz, jlong objPtr, jstring jFilePath,
	jlong startTimeMs, jlong endTimeMs, jlong scaleStartTimeMs, jlong scaleEndTimeMs, jdouble factor)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	previewManager->AddAudioClip(filePath, startTimeMs, endTimeMs, scaleStartTimeMs, scaleEndTimeMs, factor);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeAddAudioMixClip(JNIEnv *env, jobject thiz, jlong objPtr, jstring jFilePath,
	jlong startTimeMs, jlong endTimeMs, jlong scaleStartTimeMs, jlong scaleEndTimeMs, jdouble factor, jdouble weight)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	previewManager->AddMixAudioClip(filePath, startTimeMs, endTimeMs, scaleStartTimeMs, scaleEndTimeMs, factor, weight);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeAddEmptyClip(JNIEnv *env, jobject thiz, jlong objPtr, jlong timeRange)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	previewManager->AddEmptyClip(timeRange);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeAddImageClip(JNIEnv *env, jobject thiz, jlong objPtr, jstring jFilePath, jlong time)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	previewManager->AddImageClip(filePath, time);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeOnStart(JNIEnv *env, jobject thiz, jlong objPtr)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	previewManager->OnStart();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeOnDestroy(JNIEnv *env, jobject thiz, jlong objPtr)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	previewManager->OnDestroy();
	delete previewManager;
}

JNIEXPORT jlong JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeGetSourceObject(JNIEnv *env, jobject thiz, jlong objPtr)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return 0;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	return previewManager->GetSourcePtr();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeSetPause(JNIEnv *env, jobject thiz, jlong objPtr)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	previewManager->SetPause();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeSetPlayRate(JNIEnv *env, jobject thiz, jlong objPtr, jint rate)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	previewManager->SetPlayRate(PreviewManager::PLAY_SPEED_RATE(rate));
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_preview_Preview_nativeSeekValue(JNIEnv *env, jobject thiz, jlong objPtr, jlong value)
{
	if (objPtr == 0) {
		LOGE("error objPtr = 0");
		return;
	}
	auto previewManager = LONG_TO_OBJ_PTR(PreviewManager, objPtr);
	previewManager->SeekValue(value);
}

#ifdef __cplusplus
}
#endif
#endif /* _Included_com_arashivision_preview_Preview */
