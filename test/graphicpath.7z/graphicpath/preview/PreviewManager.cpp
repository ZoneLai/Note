#include "PreviewManager.h"
using namespace Oryol;
using namespace arvrender;
#define PREVIEW_PLAY_SPEED_RATE_DEFUALT			1.0
#define PREVIEW_PLAY_SPEED_RATE_QUARTER			0.25
#define PREVIEW_PLAY_SPEED_RATE_HALF			0.5
#define PREVIEW_PLAY_SPEED_RATE_DOUBLE			2.0
#define PREVIEW_PLAY_SPEED_RATE_FOUR			4.0
PreviewManager::PreviewManager()
	: sequenceSource_(nullptr)
	, previewer2_(nullptr)
	, videoTrack_(nullptr)
	, audioTrack_(nullptr)
	, mixAudioTrack_(nullptr)
	, isMixAudio_(false)
	, isPause_(false)
{
}

PreviewManager::~PreviewManager() {
}

void PreviewManager::OnCreate() {
	sequenceSource_ = std::make_shared<SequenceSource>();
	previewer2_ = std::make_shared<ins::Previewer2>();
	videoTrack_ = std::make_shared<ins::RenderTrack>(ins::AVType::VIDEO);
	audioTrack_ = std::make_shared<ins::RenderTrack>(ins::AVType::AUDIO);
	mixAudioTrack_ = std::make_shared<ins::RenderTrack>(ins::AVType::AUDIO);
}

void PreviewManager::AddVideoClip(std::string file, int64_t startTime, int64_t endTime, int64_t scaleStartTime, int64_t scaleEndTime, double factor) {
	videoTrack_->AddClip(
		std::make_shared<ins::FileClip>(
		std::vector<std::string> { file },
		startTime,
		endTime,
		ins::AVType::VIDEO,
		std::vector<ins::TimeScale> {
		ins::TimeScale(scaleStartTime, scaleEndTime, factor),
		})
	);
}

void PreviewManager::AddAudioClip(std::string file, int64_t startTime, int64_t endTime, int64_t scaleStartTime, int64_t scaleEndTime, double factor) {
	audioTrack_->AddClip(
		std::make_shared<ins::FileClip>(
		file,
		startTime,
		endTime,
		ins::AVType::AUDIO,
		std::vector<ins::TimeScale> {
		    ins::TimeScale(scaleStartTime, scaleEndTime, factor),
		})
	);
}

void  PreviewManager::AddMixAudioClip(std::string file, int64_t startTime, int64_t endTime, int64_t scaleStartTime, int64_t scaleEndTime, double factor, double weight) {
	isMixAudio_ = true;
	mixAudioTrack_->AddClip(
		std::make_shared<ins::FileClip>(
		file,
		startTime,
		endTime,
		ins::AVType::AUDIO,
		std::vector<ins::TimeScale> {
			ins::TimeScale(scaleStartTime, scaleEndTime, factor),
		})
	);
	mixAudioTrack_->SetAudioWeight(weight);
}

void PreviewManager::AddEmptyClip(int64_t time) {
	audioTrack_->AddClip(std::make_shared<ins::EmptyClip>(time));	
}

void PreviewManager::AddImageClip(std::string imageFile, int64_t time) {
	videoTrack_->AddClip(std::make_shared<ins::ImageClip>(imageFile, time));
}

void PreviewManager::OnStart() {
	std::vector<ins::sp<ins::RenderTrack>> tracks { videoTrack_, audioTrack_, mixAudioTrack_ };

	previewer2_->SetSource(tracks);
	previewer2_->SetVideoRender([this](const ins::sp<ins::VideoSampleGroup> &sampleGroup) {
		sequenceSource_->PutSample(sampleGroup);
	});

	previewer2_->SetPlayRate(PREVIEW_PLAY_SPEED_RATE_DEFUALT);
	previewer2_->PrepareAsync(0);
	previewer2_->Play();
}

void PreviewManager::OnStop() {
}

void PreviewManager::OnDestroy() {
	if (previewer2_ != nullptr) {
		previewer2_->Release();
		previewer2_ = nullptr;
	}
}

void PreviewManager::SetPause() {
	if (isPause_) {
		previewer2_->Play();
		isPause_ = false;
	} else {
		previewer2_->Pause();
		isPause_ = true;
	}
}

void PreviewManager::SetPlayRate(PreviewManager::PLAY_SPEED_RATE rate) {
	switch (rate) {
		case PreviewManager::PLAY_SPEED_RATE::DEFAULT_SPEED :
			previewer2_->SetPlayRate(PREVIEW_PLAY_SPEED_RATE_DEFUALT);
			break;
		case PreviewManager::PLAY_SPEED_RATE::QUARTER_SPEED :
			previewer2_->SetPlayRate(PREVIEW_PLAY_SPEED_RATE_QUARTER);
			break;
		case PreviewManager::PLAY_SPEED_RATE::HALF_SPEED :
			previewer2_->SetPlayRate(PREVIEW_PLAY_SPEED_RATE_HALF);
			break;
		case PreviewManager::PLAY_SPEED_RATE::DOUBLE_SPEED :
			previewer2_->SetPlayRate(PREVIEW_PLAY_SPEED_RATE_DOUBLE);
			break;
		case PreviewManager::PLAY_SPEED_RATE::FOUR_SPEED :
			previewer2_->SetPlayRate(PREVIEW_PLAY_SPEED_RATE_FOUR);
			break;
		default:
			break;
	}
}

void PreviewManager::SeekValue(int64_t value) {
	if (previewer2_ != nullptr) {
		previewer2_->Seek(value);
	}
}

long PreviewManager::GetSourcePtr() {
	return ((long)sequenceSource_.get());
}

std::shared_ptr<arvrender::SequenceSource> PreviewManager::GetSourceSharedPtr() const {
	return sequenceSource_;
}