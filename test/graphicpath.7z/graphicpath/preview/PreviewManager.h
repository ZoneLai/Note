/******************************************************************* 
 *  Copyright(c) 2017-2018 Insta360 Inc.
 *  All rights reserved. 
 *   
 *  @file 	 PreviewManager.h
 *  @brief   PreviewManager
 *   
 *  @date    2018-07-16
 *  @author  laizhongan@insta360.com 
 ******************************************************************/ 
#ifndef __PREVIEWERMANAGER_H__
#define __PREVIEWERMANAGER_H__
#include <memory>
#include <string>
#include "RenderModel/HybridRender.h"
#include "Source/SequenceSource.h"
#include "editor2/preview2/PlayPosition.h"
#include "editor2/preview2/Previewer2.h"
#include "Common.h"
class PreviewManager
{
public:
	enum class PLAY_SPEED_RATE {
		DEFAULT_SPEED 	= 0,
		QUARTER_SPEED 	= 1,
		HALF_SPEED 		= 2,
		DOUBLE_SPEED 	= 3,
		FOUR_SPEED 		= 4
	};

public:
	PreviewManager();
	~PreviewManager();
	void OnCreate();
	void AddVideoClip(std::string file, int64_t startTime, int64_t endTime, int64_t scaleStartTime, int64_t scaleEndTime, double factor);
	void AddAudioClip(std::string file, int64_t startTime, int64_t endTime, int64_t scaleStartTime, int64_t scaleEndTime, double factor);
	void AddMixAudioClip(std::string file, int64_t startTime, int64_t endTime, int64_t scaleStartTime, int64_t scaleEndTime, double factor, double weight);
	void AddEmptyClip(int64_t time);
	void AddImageClip(std::string imageFile, int64_t time);
	void OnStart();
	void OnStop();
	void OnDestroy();
	void SetPause();
	void SetPlayRate(PreviewManager::PLAY_SPEED_RATE rate);
	void SeekValue(int64_t value);
	long GetSourcePtr();
	std::shared_ptr<arvrender::SequenceSource> GetSourceSharedPtr() const;

private:
	std::shared_ptr<arvrender::SequenceSource> sequenceSource_;
	std::shared_ptr<ins::Previewer2> previewer2_;
	std::shared_ptr<ins::RenderTrack> videoTrack_;
	std::shared_ptr<ins::RenderTrack> audioTrack_;
	std::shared_ptr<ins::RenderTrack> mixAudioTrack_;
	bool isMixAudio_;
	bool isPause_;
};

#endif /* __PREVIEWERMANAGER_H__ */