// Copyright 2017, Insta360 Inc.
// All rights reserved.
// Author: jerett@insta360.com (WenJie Jiang)
#ifndef _Included_com_arashivision_graphicpath_render_HybridRender
#define _Included_com_arashivision_graphicpath_render_HybridRender
#include "HybridRenderInfo.h"
#include "jniutils/JniObject.h"
#include "Source/SequenceSource.h"
#include "PreviewManager.h"
#include "Common.h"
using namespace Oryol;
using namespace arvrender;

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeOnCreate(JNIEnv *env, jobject thiz)
{
    Ptr<PlatformData> platformData(Memory::New<PlatformData>());
    HybridRender *render = new HybridRender(platformData);
    SetRender(env, thiz, render);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeInitHyBridVideoRender(JNIEnv *env, jobject thiz, jstring jFilePath)
{
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	HybridRender* render = GetRender(env, thiz);
	std::shared_ptr<Source> source = std::make_shared<VideoAssetSource>(filePath);
	RenderModelType modelType(RenderModelType::Type::SPHERE_AUTO);
	std::shared_ptr<StabilizerFeatureSetup> stabilize = std::make_shared<StabilizerFeatureSetup>();
	stabilize->SetSwitch(StabilizerFeatureSetup::Switch::OFF);
	render->SetStabilizerFeature(stabilize);
	render->SetSourceAndRenderModelType(source, modelType);
	render->Start();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeInitHyBridImageRender(JNIEnv *env, jobject thiz, jstring jFilePath)
{
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	HybridRender* render = GetRender(env, thiz);
	std::shared_ptr<Source> source = std::make_shared<ImageAssetSource>(filePath);
	RenderModelType modelType(RenderModelType::Type::SPHERE_AUTO);
	std::shared_ptr<StabilizerFeatureSetup> stabilize = std::make_shared<StabilizerFeatureSetup>();
	stabilize->SetSwitch(StabilizerFeatureSetup::Switch::OFF);
	render->SetStabilizerFeature(stabilize);
	render->SetSourceAndRenderModelType(source, modelType);
	render->Start();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeOnStart(JNIEnv *env, jobject thiz)
{
	HybridRender* render = GetRender(env, thiz);
	render->Start();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeOnPause(JNIEnv *env, jobject thiz)
{
	HybridRender* render = GetRender(env, thiz);
	render->Pause();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeOnDestroy(JNIEnv *env, jobject thiz)
{
	HybridRender* render = GetRender(env, thiz);
	render->Quit();
	delete render;
	SetRender(env, thiz, nullptr);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeSetLogoFeature(JNIEnv *env, jobject thiz, jstring jFilePath, jint jFlag)
{
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	HybridRender* render = GetRender(env, thiz);
	std::shared_ptr<ImageAsset> source = std::make_shared<ImageAsset>(filePath);
	if (jFlag == 0) {
		std::shared_ptr<LogoFeatureSetup> requestLogoFeature = std::make_shared<LogoFeatureSetup>(LogoFeatureSetup::Switch::AUTO, source);  // Extra
		render->SetLogoFeature(requestLogoFeature);
	} else if (jFlag == 1) {
		std::shared_ptr<LogoFeatureSetup> requestLogoFeature = std::make_shared<LogoFeatureSetup>(LogoFeatureSetup::Switch::ON, source);    // ON
		render->SetLogoFeature(requestLogoFeature);
	} else if (jFlag == 2) {
		std::shared_ptr<LogoFeatureSetup> requestLogoFeature = std::make_shared<LogoFeatureSetup>(LogoFeatureSetup::Switch::OFF, source);   // OFF
		render->SetLogoFeature(requestLogoFeature);
	}
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeSetStabilizerFeature(JNIEnv *env, jobject thiz, jint jSwitch)
{
	HybridRender* render = GetRender(env, thiz);
	std::shared_ptr<StabilizerFeatureSetup> stabilize = render->GetStabilizerFeature();
	StabilizerFeatureSetup::Switch mSwitch = StabilizerFeatureSetup::Switch(jSwitch);
	stabilize->SetSwitch(mSwitch);
	render->SetStabilizerFeature(stabilize);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeSetImageFilterFeature(JNIEnv *env, jobject thiz)
{
	HybridRender* render = GetRender(env, thiz);
	// TODO...
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeSetSphereViewMode(JNIEnv *env, jobject thiz, jint jViewType)
{
	HybridRender* render = GetRender(env, thiz);
	SphereViewMode sphereViewMode;
	if (jViewType == 0) {
		sphereViewMode = SphereViewMode::Fisheye();		// FISHEYE
	} else if (jViewType == 1) {
		sphereViewMode = SphereViewMode::Perspective();	// PERSPECTIVE
	} else if (jViewType == 2) {
		sphereViewMode = SphereViewMode::Asteroid();	// ASTEROID
	} else if (jViewType == 3) {
		sphereViewMode = SphereViewMode::MagicBall();	// MAGICBALL
	}
	render->SetSphereViewMode(sphereViewMode);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeSetRenderModelType(JNIEnv *env, jobject thiz, jint jRenderType)
{
	HybridRender* render = GetRender(env, thiz);
	RenderModelType::Type type = RenderModelType::Type(jRenderType);
	RenderModelType::Type defaultTpye = render->GetRenderModelType().GetType();
	if (defaultTpye == type)
		return;
	RenderModelType modelType(type);
	render->SetRenderModelType(modelType);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeAddSticker(JNIEnv *env, jobject thiz, jstring jFilePath, jfloat jSize, jfloat x, jfloat y)
{
	std::string filePath = anbase::JavaStringToString(jFilePath, env);
	HybridRender* render = GetRender(env, thiz);
	std::shared_ptr<ImageAsset> source = std::make_shared<ImageAsset>(filePath);
	glm::vec2 point(x, y);
	std::shared_ptr<StickerSetup> sticker = std::make_shared<StickerSetup>(jSize, source);
	render->AddSticker(sticker, point);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_render_HybridRender_nativeSetSource(JNIEnv *env, jobject thiz, jlong sourcePtr)
{
	if (sourcePtr == 0) {
		return;
	}
	HybridRender* render = GetRender(env, thiz);
	PreviewManager* previewManager = LONG_TO_OBJ_PTR(PreviewManager, sourcePtr);
	RenderModelType modelType(RenderModelType::Type::PLANE);
	render->SetSourceAndRenderModelType(previewManager->GetSourceSharedPtr(), modelType);
	render->SetSphereViewMode(SphereViewMode::Fisheye());
	render->Start();
}

#ifdef __cplusplus
}
#endif
#endif
