#pragma once
#include <RenderModel/HybridRender.h>
#include <jniutils/JniUtils.h>

arvrender::HybridRender* GetRender(JNIEnv *env, jobject thiz);
void SetRender(JNIEnv *env, jobject thiz, arvrender::HybridRender *render);