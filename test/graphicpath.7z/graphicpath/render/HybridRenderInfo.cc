#include "HybridRenderInfo.h"

static anbase::JavaClassJvmData HybridRender_JvmInfo;

static anbase::JavaClassInfo HybridRender_ClassInfo = {
	// class name
	"",
	// object fields
	{
		{"mNativeInstance", "J"},
	},
	// static fields
	{
	},
	// object methods
	{
	},
	// static methods
	{
	},
	// constructors
	{
	},
	&HybridRender_JvmInfo,
};

arvrender::HybridRender* GetRender(JNIEnv *env, jobject thiz)
{
    anbase::JavaObject caller(&HybridRender_ClassInfo, thiz, env);
    return (arvrender::HybridRender*)caller.getLong("mNativeInstance");
}

void SetRender(JNIEnv *env, jobject thiz, arvrender::HybridRender *render)
{
    anbase::JavaObject caller(&HybridRender_ClassInfo, thiz, env);
    caller.setLong("mNativeInstance", (jlong)(intptr_t)render);
}