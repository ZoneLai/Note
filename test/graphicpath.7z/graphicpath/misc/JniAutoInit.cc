#include <jniutils/JniUtils.h>
#include <llog/llog.h>

extern "C" void av_register_all(void);
extern "C" void avformat_network_init(void);
extern "C" int av_jni_set_java_vm(void *vm, void *log_ctx);


anbase::JvmOnLoadAutoRun _graphicPathAutoInit([]() {
    ins::Log.i("graphicpath", "graphicpath: register ffmpeg modules");
    av_register_all();
    avformat_network_init();
    av_jni_set_java_vm(anbase::GetJvm(), nullptr);
});
