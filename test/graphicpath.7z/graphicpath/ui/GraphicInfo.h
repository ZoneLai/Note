#pragma once
#include "jniutils/JniUtils.h"
#include "sys/Clock.h"
#include <Core/Platform.h>
#include <Core/Time/Clock.h>

Oryol::GraphicView *GetGraphicView(JNIEnv *env, jobject thiz, int64_t* timeDelta = nullptr);

void SetGraphicView( JNIEnv *env, jobject thiz, Oryol::GraphicView *view);

