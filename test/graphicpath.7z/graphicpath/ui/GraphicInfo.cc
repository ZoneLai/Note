#include "GraphicInfo.h"

static anbase::JavaClassJvmData GraphicView_JvmInfo;
static anbase::JavaClassInfo GraphicView_ClassInfo = {
    // class name
    "",
    // object fields
    {
        {"mNativeInstance", "J"},
    },
    // static fields
    {
    },
    // object methods
    {
    },
    // static methods
    {
    },
    // constructors
    {
    },
    &GraphicView_JvmInfo
};

struct Context {
    Oryol::GraphicView *view;
    int64_t timeDelta;
};

static Context* GetContext(JNIEnv *env, jobject thiz)
{
    anbase::JavaObject caller(&GraphicView_ClassInfo, thiz, env);
    Context *context = (Context *)caller.getLong("mNativeInstance");
    return context;
}

Oryol::GraphicView* GetGraphicView(JNIEnv *env, jobject thiz, int64_t* timeDelta)
{
    anbase::JavaObject caller(&GraphicView_ClassInfo, thiz, env);
    Context *context = (Context *)caller.getLong("mNativeInstance");
    if(context == nullptr)
        return nullptr;
    if(timeDelta != nullptr)
        *timeDelta = context->timeDelta;
    return context->view;
}

void SetGraphicView(JNIEnv *env, jobject thiz, Oryol::GraphicView* view)
{
    Context *context = GetContext(env, thiz);
    anbase::JavaObject caller(&GraphicView_ClassInfo, thiz, env);
    if(view == nullptr) {
        if(context != nullptr) {
            context->view = nullptr;
            delete context;
        }
        caller.setLong("mNativeInstance", (jlong)(intptr_t)context);
        return;
    }
    o_assert(context == nullptr);
    int64_t clockTimeUs 		= anbase::SystemClock_uptimeMillis() * 1000;
    int64_t oryolClockTimeUs 	= Oryol::Clock::Now().getRaw();
    int64_t timeDelta 			= oryolClockTimeUs - clockTimeUs;
    context 					= new Context{ view, timeDelta };
    caller.setLong("mNativeInstance", (jlong)(intptr_t)context);
}
