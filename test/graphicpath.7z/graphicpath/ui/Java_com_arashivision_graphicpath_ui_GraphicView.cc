#ifndef _Included_com_arashivision_graphicpath_ui_GraphicView
#define _Included_com_arashivision_graphicpath_ui_GraphicView
#include "GraphicInfo.h"
using namespace Oryol;
#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeCreate(JNIEnv *env, jobject thiz)
{
    GraphicView *view = new GraphicView();
    o_info("new grahic view: %p\n", view);
    SetGraphicView(env, thiz, view);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeDestroy(JNIEnv *env, jobject thiz)
{
    GraphicView *view = GetGraphicView(env, thiz);
	delete view;
    SetGraphicView(env, thiz, nullptr);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeSurfaceCreated(JNIEnv *env, jobject thiz, jobject jSurface, jint jWidth, jint jHeight)
{
    GraphicView *view = GetGraphicView(env, thiz);
    view->onSurfaceCreated(jSurface, jWidth, jHeight, env);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeSurfaceChanged(JNIEnv *env, jobject thiz, jint jWidth, jint jHeight)
{
    GraphicView *view = GetGraphicView(env, thiz);
    view->onSurfaceSizeChanged(jWidth, jHeight);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeSurfaceDestroyed(JNIEnv *env, jobject thiz)
{
    GraphicView *view = GetGraphicView(env, thiz);
    view->onSurfaceDestroy();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeSetRender(JNIEnv *env, jobject thiz, jlong jRender)
{
    App *render = (App *)(intptr_t)jRender;
    GraphicView *view = GetGraphicView(env, thiz);
    view->setRenderer(render);
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeRemoveRender(JNIEnv *env, jobject thiz)
{
    GraphicView *view = GetGraphicView(env, thiz);
    view->removeRenderer();
}

JNIEXPORT void JNICALL Java_com_arashivision_graphicpath_ui_GraphicView_nativeOnTouch(JNIEnv *env, jobject thiz, 
		jint actionMasked, jint actionIndex, jint pointerCount, jlong eventTime, 
		jfloatArray jXList, jfloatArray jYList, jintArray jPointerIDList)
{
    o_assert(pointerCount <= 10);
    int64_t timeDeltaUs;
    GraphicView *view = GetGraphicView(env, thiz, &timeDeltaUs);
    if(view == nullptr)
        return;
    int64_t adjustedTime 			= ((int64_t)eventTime * 1000) + timeDeltaUs;
    std::vector<float> xList 		= anbase::JavaFloatArrayToVector(jXList, env);
    std::vector<float> yList 		= anbase::JavaFloatArrayToVector(jYList, env);
    std::vector<int> pointerIDList 	= anbase::JavaIntArrayToVector(jPointerIDList, env);
    MotionEvent::PointerData pointerData[10];
    for(int i = 0; i < pointerCount; ++i) {
        pointerData[i].pointerId 	= pointerIDList[i];
        pointerData[i].x 			= xList[i];
        pointerData[i].y 			= yList[i];
    }
    std::shared_ptr<MotionEvent> motionEvent(new MotionEvent(actionMasked, actionIndex, pointerCount, adjustedTime, pointerData));
    view->onMotionEvent(motionEvent);
}

#ifdef __cplusplus
}
#endif
#endif /** _Included_com_arashivision_graphicpath_ui_GraphicView **/
